package com.sevenbulb.webproject.common;

public class Constants {
    public final static int TOKEN_LENGTH = 32;
}

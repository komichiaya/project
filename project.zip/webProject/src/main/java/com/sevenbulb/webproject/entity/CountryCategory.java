package com.sevenbulb.webproject.entity;

import lombok.Data;

@Data
public class CountryCategory {
    private Long countryId;
    private String countryName;
}

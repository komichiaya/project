package com.sevenbulb.webproject.service;

import com.sevenbulb.webproject.entity.UserForm;

public interface UserFormService {
    /**
     * 添加
     *
     * @param from
     * @return
     */
    String saveUserForm(UserForm from);
}
